let arvores = [];
let flores = []; // New array to store flower positions

function setup() {
  createCanvas(800, 400);
  textFont('Georgia');
}

function draw() {
  background(135, 206, 235); // céu azul claro

  // Desenha o sol
  drawSol();

  // Desenha as nuvens azuis
  drawNuvens();

  // chão
  fill(85, 107, 47);
  rect(0, height * 0.75, width, height * 0.25);

  // título
  fill(0);
  textSize(20);
  textAlign(CENTER);
  text("Clique na terra para plantar árvores e conectar campo e cidade!", width / 2, 30);

  // desenha árvores já plantadas
  for (let arvore of arvores) {
    drawArvore(arvore.x, arvore.y);
  }

  // desenha flores já plantadas
  for (let flor of flores) {
    drawFlor(flor.x, flor.y);
  }
}

// função de clique do mouse
function mousePressed() {
  if (mouseY > height * 0.75) {
    // adiciona árvore
    arvores.push({ x: mouseX, y: mouseY });

    // Verifica se é hora de plantar uma flor (a cada 3 árvores)
    if (arvores.length % 3 === 0) { // <--- MUDANÇA AQUI: de 5 para 3
      flores.push({ x: mouseX + random(-20, 20), y: mouseY + random(5, 15) }); // Adiciona uma flor perto da árvore
    }
  }
}

// função para desenhar uma árvore simples
function drawArvore(x, y) {
  // tronco
  fill(139, 69, 19);
  rect(x - 5, y - 40, 10, 40);

  // copa verde
  fill(34, 139, 34);
  ellipse(x, y - 50, 40, 40);
  ellipse(x - 10, y - 60, 35, 35);
  ellipse(x + 10, y - 60, 35, 35);
}

// Função para desenhar o sol
function drawSol() {
  fill(255, 204, 0); // Amarelo para o sol
  noStroke();
  ellipse(width - 80, 80, 100, 100);
}

// Função para desenhar nuvens azuis
function drawNuvens() {
  // Nuvem 1 (azul claro)
  fill(173, 216, 230, 200); // Azul claro com transparência
  noStroke();
  ellipse(150, 100, 100, 60);
  ellipse(180, 80, 80, 50);
  ellipse(120, 90, 70, 45);

  // Nuvem 2 (azul médio)
  fill(100, 149, 237, 200); // Azul médio com transparência
  noStroke();
  ellipse(550, 120, 120, 70);
  ellipse(580, 100, 90, 60);
  ellipse(520, 110, 80, 55);

  // Nuvem 3 (azul acinzentado)
  fill(176, 196, 222, 200); // Azul acinzentado com transparência
  noStroke();
  ellipse(350, 70, 90, 50);
  ellipse(380, 60, 70, 40);
  ellipse(320, 65, 60, 35);
}

// Função para desenhar uma flor vermelha com miolo amarelo
function drawFlor(x, y) {
  noStroke();

  // Pétalas vermelhas
  fill(255, 0, 0); // Vermelho puro
  ellipse(x, y - 5, 15, 15);
  ellipse(x - 5, y, 15, 15);
  ellipse(x + 5, y, 15, 15);
  ellipse(x, y + 5, 15, 15);
  ellipse(x - 4, y - 4, 15, 15);
  ellipse(x + 4, y - 4, 15, 15);
  ellipse(x - 4, y + 4, 15, 15);
  ellipse(x + 4, y + 4, 15, 15);


  // Miolo amarelo
  fill(255, 255, 0); // Amarelo puro
  ellipse(x, y, 8, 8); // Miolo central
}